import streamlit as st
import pyodbc
import pandas as pd
from sklearn.preprocessing import StandardScaler
import numpy as np


# Database connection function
def create_connection():
    connection_string = (
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=DESKTOP-0S0IFEA;"  
        "DATABASE=StreamingDW2;"  
        "Trusted_Connection=yes;"
    )
    conn = pyodbc.connect(connection_string)
    return conn


# SQL query to retrieve customer-specific data
def get_customer_data(customer_id, conn):
    query = f"""
SELECT
    f.FactKey,
    f.ActivityDateKey,
    f.ProfileKey,
    f.CustomerKey,
    f.MovieKey,
    f.PlanKey,
    f.UserRating,
    f.ActivityDuration,
    f.CompletionPrecentage,  -- Assuming this is the correct spelling in your database
    f.PaymentAmount,
    f.StartDateKey,
    f.EndDateKey,
    f.ActivityType,
    f.watchHistoryDateKey,
    -- Customer data
    c.Name AS CustomerName,
    c.Email AS CustomerEmail,
    c.City AS CustomerCity,
    c.State AS CustomerState,
    c.Country AS CustomerCountry,
    c.PostalCode AS CustomerPostalCode,
    c.SubscriptionStatus AS IsChurned,
    -- Profile data
    p.UserName AS ProfileUserName,
    p.Gender AS ProfileGender,
    p.BirthDate AS ProfileBirthDate,
    p.ProfileCreationDate AS ProfileCreated,
    p.AppRating AS ProfileAppRating,
    -- Plan data
    pl.PlanName AS SubscriptionPlan
FROM
    FactStreamingDW2 f
-- Join with DimCustomer
LEFT JOIN
    DimCustomer c ON f.CustomerKey = c.CustomerKey
-- Join with DimProfile
LEFT JOIN
    DimProfile p ON f.ProfileKey = p.ProfileKey
-- Join with DimPlan
LEFT JOIN
    DimPlan pl ON f.PlanKey = pl.PlanKey
WHERE
    c.CustomerID = '{customer_id}'  -- Input for CustomerID
ORDER BY
    f.FactKey;


    """
    df = pd.read_sql(query, conn)
    return df


# Churn calculation function
def calc_churn(df):
    engagement_weight = 0.5
    monetary_weight = 0.3
    user_satisfaction_weight = 0.2

    # Engagement  (based on ActivityDuration)
    df['LowEngagementFlag'] = np.where(df['ActivityDuration'] < 5, 0.7,
                                       np.where(df['ActivityDuration'] < 7, 0.4, 0))

    # Monetary  (based on PaymentAmount)
    df['LowMonetaryFlag'] = np.where(df['PaymentAmount'] < 30, 0.7,
                                     np.where(df['PaymentAmount'] < 50, 0.4, 0))

    # User satisfaction  (based on UserRating and ProfileAppRating)
    df['LowSatisfactionFlag'] = np.where((df['UserRating'] < 3) | (df['ProfileAppRating'] < 3), 0.7, 0)

    # Calculate churn tendency
    df['churn_tendency'] = (
                                   (df['LowEngagementFlag'] * engagement_weight) +
                                   (df['LowMonetaryFlag'] * monetary_weight) +
                                   (df['LowSatisfactionFlag'] * user_satisfaction_weight)
                           ) * 100

    # churn if tendency > 30%
    df['churn_label'] = np.where(df['churn_tendency'] > 30, 1, 0)

    return df


# Streamlit UI
def main():
    st.title("Customer Churn Prediction App")

    customer_id = st.text_input("Enter Customer ID", value="")

    if st.button("Get Churn Prediction"):
        if customer_id:
            conn = create_connection()
            customer_data = get_customer_data(customer_id, conn)

            if customer_data.empty:
                st.warning(f"Sorry, no data found for Customer ID: {customer_id}")
            else:
                # Calculate churn
                customer_data_with_churn = calc_churn(customer_data)

                # Display churn tendency and label
                churn_tendency = customer_data_with_churn['churn_tendency'].iloc[0]
                churn_label = customer_data_with_churn['churn_label'].iloc[0]

                st.write(f"Churn Tendency: {churn_tendency:.2f}%")
                st.write(f"Churn Label: {'Churn' if churn_label == 1 else 'Not Churn'}")
        else:
            st.warning("Please enter a valid Customer ID.")


if __name__ == '__main__':
    main()
